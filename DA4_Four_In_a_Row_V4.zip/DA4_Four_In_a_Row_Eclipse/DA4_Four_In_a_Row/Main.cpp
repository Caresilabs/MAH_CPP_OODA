#include <iostream>
#include "MainWindow.h"

void main() {
	MainWindow mainWindow;

	return;
}


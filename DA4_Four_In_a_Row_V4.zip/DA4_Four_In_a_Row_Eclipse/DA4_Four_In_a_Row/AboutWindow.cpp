#include "AboutWindow.h"
#include <iostream>

void AboutWindow::show() {
	std::cout << "Made by the almighty Jonas. (c) 1999\n";

	system("pause");
}

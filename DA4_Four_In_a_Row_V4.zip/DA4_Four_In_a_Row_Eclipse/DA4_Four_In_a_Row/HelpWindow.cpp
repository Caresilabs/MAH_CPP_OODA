#include "HelpWindow.h"
#include <iostream>



void HelpWindow::show() {
	std::cout << "Do get 4 in row, you win!\n";

	system("pause");
}